public class ContaCorrente extends Conta {
    private double limite;

    public ContaCorrente(String numero, Cliente cliente, double limite) {
        super(numero, cliente, "ContaCorrente");
        this.limite = limite;
    }

    @Override
    protected boolean podeSacar(double valor) {
        return (saldo + limite) >= valor;
    }
}
