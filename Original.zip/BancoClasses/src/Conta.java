import java.util.ArrayList;
import java.util.List;

public abstract class Conta {
    protected String numero;
    protected double saldo;
    protected Cliente cliente;
    protected String tipo;
    private List<Transacao> historico = new ArrayList<>();

    public Conta(String numero, Cliente cliente, String tipo) {
        this.numero = numero;
        this.cliente = cliente;
        this.tipo = tipo;
        this.saldo = 0.0;
    }

    public void depositar(double valor) {
        if (valor <= 0) {
            System.out.println("Valor de depósito inválido.");
            return;
        }
        this.saldo += valor;
        registrarTransacao("DEPOSITO", valor, "Depósito em conta");
    }

    public boolean sacar(double valor) {
        if (valor <= 0) {
            System.out.println("Valor de saque inválido.");
            return false;
        }
        if (!podeSacar(valor)) {
            System.out.println("Saldo insuficiente.");
            return false;
        }
        this.saldo -= valor;
        registrarTransacao("SAQUE", valor, "Saque em conta");
        return true;
    }

    public boolean transferir(Conta destino, double valor) {
        if (destino == null) {
            System.out.println("Conta destino não encontrada.");
            return false;
        }
        if (this.sacar(valor)) {
            destino.depositar(valor);
            registrarTransacao("TRANSFERENCIA", valor,
                    "Transferência para conta " + destino.numero);
            return true;
        }
        return false;
    }

    public double getSaldo() { return saldo; }

    protected void registrarTransacao(String tipo, double valor, String descricao) {
        historico.add(new Transacao(valor, tipo, descricao));
    }

    public void imprimirHistorico() {
        if (historico.isEmpty()) {
            System.out.println("Sem transações.");
            return;
        }
        for (Transacao t : historico) {
            System.out.println(t);
        }
    }

    protected abstract boolean podeSacar(double valor);

    @Override
    public String toString() {
        return String.format("%s %s | Titular: %s | Saldo: %.2f",
                tipo, numero, cliente.getNome(), saldo);
    }

    public String getNumero() { return numero; }
    public Cliente getCliente() { return cliente; }
}
