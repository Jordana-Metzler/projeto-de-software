import java.util.*;

public class Banco {
    private String nome;
    private List<Conta> contas = new ArrayList<>();

    public Banco(String nome) {
        this.nome = nome;
    }

    public void criarConta(Conta conta) {
        contas.add(conta);
        System.out.println("Conta criada: " + conta);
    }

    public void fecharConta(String numero) {
        contas.removeIf(c -> c.getNumero().equals(numero));
        System.out.println("Conta " + numero + " fechada (se existia).");
    }

    public void listarContas() {
        if (contas.isEmpty()) {
            System.out.println("Não há contas.");
            return;
        }
        for (Conta c : contas) {
            System.out.println(c);
        }
    }

    public void listarClientes() {
        if (contas.isEmpty()) {
            System.out.println("Não há clientes.");
            return;
        }
        Set<String> infos = new LinkedHashSet<>();
        for (Conta c : contas) {
            infos.add(c.getCliente().getInfo());
        }
        for (String info : infos) System.out.println(info);
    }

    public Conta encontrarContaPorNumero(String numero) {
        for (Conta c : contas) {
            if (c.getNumero().equals(numero)) return c;
        }
        return null;
    }
}
