public class ContaPoupanca extends Conta {
    private double rendimento; // ex: 0.005 = 0,5% ao mês

    public ContaPoupanca(String numero, Cliente cliente, double rendimento) {
        super(numero, cliente, "ContaPoupanca");
        this.rendimento = rendimento;
    }

    @Override
    protected boolean podeSacar(double valor) {
        return saldo >= valor; // sem cheque especial
    }

    // extra opcional
    public void aplicarRendimentoMensal() {
        double ganho = saldo * rendimento;
        if (ganho > 0) {
            saldo += ganho;
            registrarTransacao("RENDIMENTO", ganho, "Rendimento mensal poup.");
        }
    }
}
