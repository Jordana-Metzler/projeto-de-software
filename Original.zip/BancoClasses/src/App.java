
public class App {

    public static void main(String[] args) {
        // cria banco com dados mockados (já imprime as operações iniciais)
        Banco banco = criar_dados_mock();

        System.out.println("\n=== LISTAR CLIENTES ===");
        banco.listarClientes();

        System.out.println("\n=== LISTAR CONTAS ===");
        banco.listarContas();

        // Pegar duas contas para demonstrar as operações
        Conta contaA = banco.encontrarContaPorNumero("001");
        Conta contaB = banco.encontrarContaPorNumero("002");

        // Exemplos adicionais (também imprimindo no formato pedido)
        System.out.println("\n=== OPERACOES DEMONSTRATIVAS ===");
        contaA.depositar(300);
        System.out.printf("depósito de %.2f | saldo: %.2f (conta %s)\n",
                300.0, contaA.getSaldo(), contaA.getNumero());

        if (contaA.sacar(200)) {
            System.out.printf("saque de %.2f | saldo: %.2f (conta %s)\n",
                    200.0, contaA.getSaldo(), contaA.getNumero());
        }

        if (contaA.transferir(contaB, 150)) {
            System.out.printf("transferência de %.2f (%s -> %s) | saldo origem: %.2f | saldo destino: %.2f\n",
                    150.0, contaA.getNumero(), contaB.getNumero(),
                    contaA.getSaldo(), contaB.getSaldo());
        }

        System.out.println("\n=== HISTORICO DA CONTA 001 ===");
        contaA.imprimirHistorico();

        System.out.println("\n=== HISTORICO DA CONTA 002 ===");
        contaB.imprimirHistorico();
    }

    // OBRIGATÓRIA: popula dados de teste no banco
    // Agora, imprime cada transação realizada durante a criação dos dados
    public static Banco criar_dados_mock() {
        System.out.println("=== CRIANDO DADOS MOCK ===");
        Banco banco = new Banco("Banco Exemplo");

        Cliente c1 = new Cliente("Ana Silva", "111.111.111-11", "Rua A, 10", "(51) 90000-0001");
        Cliente c2 = new Cliente("Bruno Souza", "222.222.222-22", "Rua B, 20", "(51) 90000-0002");
        Cliente c3 = new Cliente("Carla Lima", "333.333.333-33", "Rua C, 30", "(51) 90000-0003");

        Conta cc1 = new ContaCorrente("001", c1, 500);   // limite 500
        Conta cp2 = new ContaPoupanca("002", c2, 0.005); // 0,5% ao mês (exemplo)
        Conta cc3 = new ContaCorrente("003", c3, 300);

        banco.criarConta(cc1);
        banco.criarConta(cp2);
        banco.criarConta(cc3);

        // Operações iniciais com impressão no formato solicitado
        cc1.depositar(1000);
        System.out.printf("depósito de %.2f | saldo: %.2f (conta %s)\n",
                1000.0, cc1.getSaldo(), cc1.getNumero());

        cp2.depositar(200);
        System.out.printf("depósito de %.2f | saldo: %.2f (conta %s)\n",
                200.0, cp2.getSaldo(), cp2.getNumero());

        cc3.depositar(50);
        System.out.printf("depósito de %.2f | saldo: %.2f (conta %s)\n",
                50.0, cc3.getSaldo(), cc3.getNumero());

        // exemplo de saque e transferência já no mock
        if (cc3.sacar(20)) {
            System.out.printf("saque de %.2f | saldo: %.2f (conta %s)\n",
                    20.0, cc3.getSaldo(), cc3.getNumero());
        }

        if (cp2.transferir(cc1, 50)) {
            System.out.printf("transferência de %.2f (%s -> %s) | saldo origem: %.2f | saldo destino: %.2f\n",
                    50.0, cp2.getNumero(), cc1.getNumero(),
                    cp2.getSaldo(), cc1.getSaldo());
        }

        return banco;
    }
}
