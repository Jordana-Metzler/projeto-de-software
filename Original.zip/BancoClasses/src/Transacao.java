import java.time.LocalDateTime;

public class Transacao {
    private static int SEQ = 1;

    private int id;
    private LocalDateTime data;
    private double valor;
    private String tipo;
    private String descricao;

    public Transacao(double valor, String tipo, String descricao) {
        this.id = SEQ++;
        this.data = LocalDateTime.now();
        this.valor = valor;
        this.tipo = tipo;
        this.descricao = descricao;
    }

    public void registrar() {
        // neste exemplo, existir no histórico já é "registrar"
    }

    @Override
    public String toString() {
        return String.format("#%d | %s | %s | Valor: %.2f | %s",
                id, data, tipo, valor, descricao);
    }
}
