**Antes:**  
A classe principal criava o banco, imprimia coisas na tela e também fazia operações direto nas contas.


public class App {

    public static void main(String[] args) {
        // cria banco com dados mockados (já imprime as operações iniciais)
        Banco banco = criar_dados_mock();

        System.out.println("\n=== LISTAR CLIENTES ===");
        banco.listarClientes();

        System.out.println("\n=== LISTAR CONTAS ===");
        banco.listarContas();

        // Pegar duas contas para demonstrar as operações
        Conta contaA = banco.encontrarContaPorNumero("001");
        Conta contaB = banco.encontrarContaPorNumero("002");

        contaA.depositar(300, "Depósito inicial");
        contaA.transferir(contaB, 100, "Transferência teste");

        System.out.println("Saldo final conta A: " + contaA.getSaldo());
        System.out.println("Saldo final conta B: " + contaB.getSaldo());
    }
}

**Depois:**
Agora a classe App só inicializa os serviços e chama as operações de forma organizada.

public class App {
    public static void main(String[] args) {
        AccountRepository repo = new InMemoryAccountRepository();
        Notifier notifier = new ConsoleNotifier();
        Logger logger = new ConsoleLogger();

        FeePolicy fee = new BasicFeePolicy();
        TransferService transferService = new TransferService(repo, fee, notifier, logger);

        // popular dados iniciais
        Seed.seed(repo);

        // buscar contas
        Conta origem = repo.findByNumero("001").orElseThrow();
        Conta destino = repo.findByNumero("002").orElseThrow();

        // executar operação
        transferService.transferir(origem, destino, 100.0, "PIX apresentação");

        // mostrar saldos
        System.out.println("Saldo final origem: " + origem.getSaldo());
        System.out.println("Saldo final destino: " + destino.getSaldo());
    }
}

**Conceito:**
DIP e SRP. A App agora só monta os objetos e chama os serviços. As regras de negócio ficam em classes separadas.

Com DIP, o App depende de interfaces, não de implementações fixas.