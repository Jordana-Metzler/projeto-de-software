public class Transacao {
    private static int SEQ = 1;

    private final int id;
    private final LocalDateTime data;
    private final double valor;
    private final String tipo;
    private final String descricao;

    public Transacao(double valor, String tipo, String descricao) {
        if (valor <= 0) throw new IllegalArgumentException("valor inválido");
        this.id = SEQ++;
        this.data = LocalDateTime.now();
        this.valor = valor;
        this.tipo = Objects.requireNonNull(tipo);
        this.descricao = Objects.requireNonNull(descricao);
    }

    @Override
    public String toString() {
        return String.format("#%d | %s | %s | Valor: %.2f | %s",
                id, data, tipo, valor, descricao);
    }
}
