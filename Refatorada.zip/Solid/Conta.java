**Antes:** 
A conta tinha depósitos, saques, transferências e histórico, mas podia ter comportamentos diferentes dependendo da conta filha, às vezes sem deixar claro.

public abstract class Conta {
    protected String numero;
    protected double saldo;
    protected Cliente cliente;
    protected String tipo;
    private List<Transacao> historico = new ArrayList<>();

    public Conta(String numero, Cliente cliente, String tipo) {
        this.numero = numero;
        this.cliente = cliente;
        this.tipo = tipo;
        this.saldo = 0.0;
    }

    // depositar/sacar/transferir + historico + podeSacar + toString com 'tipo'...
}

**Depois:**
Criei interfaces menores (depositar, sacar, transferir) e defini regras claras que todas as contas têm que seguir.

public abstract class Conta implements Depositable, Withdrawable, Transferable {
    protected final String numero;
    protected double saldo;
    protected final Cliente cliente;
    private final List<Transacao> historico = new ArrayList<>();

    protected Conta(String numero, Cliente cliente) {
        this.numero = Objects.requireNonNull(numero);
        this.cliente = Objects.requireNonNull(cliente);
    }

    @Override
    public boolean depositar(double valor, String descricao) {
        validarValorPositivo(valor);
        saldo += valor;
        registrarTransacao("DEPOSITO", valor, descricao);
        return true;
    }

    @Override
    public boolean sacar(double valor, String descricao) throws SaldoInsuficienteException {
        validarValorPositivo(valor);
        if (!podeSacar(valor)) throw new SaldoInsuficienteException();
        saldo -= valor;
        registrarTransacao("SAQUE", valor, descricao);
        return true;
    }

    @Override
    public boolean transferir(Conta destino, double valor, String descricao) throws SaldoInsuficienteException {
        validarValorPositivo(valor);
        if (!podeSacar(valor)) throw new SaldoInsuficienteException();
        this.saldo -= valor;
        destino.saldo += valor;
        registrarTransacao("TRANSFERENCIA", valor, descricao + " -> " + destino.numero);
        destino.registrarTransacao("TRANSFERENCIA", valor, descricao + " <- " + this.numero);
        return true;
    }

    protected abstract boolean podeSacar(double valor);

    protected void registrarTransacao(String tipo, double valor, String descricao) {
        historico.add(new Transacao(valor, tipo, descricao));
    }

    protected void validarValorPositivo(double v) {
        if (v <= 0) throw new IllegalArgumentException("valor inválido");
    }

    public String getNumero() { return numero; }
    public Cliente getCliente() { return cliente; }
    public double getSaldo() { return saldo; }

    @Override
    public String toString() {
        return String.format("%s %s | Titular: %s | Saldo: %.2f",
            getClass().getSimpleName(), numero, cliente.getNome(), saldo);
    }
}

**Conceito:** 
LSP e ISP. Agora todas as contas seguem as mesmas regras de contrato (LSP) e cada parte do sistema pode usar só as funções que precisa (ISP).