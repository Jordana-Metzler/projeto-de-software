**Antes:**
Tinha a regra de saque normal e aplicava rendimento.

public class ContaPoupanca extends Conta {
    private double rendimento; // ex: 0.005 = 0,5% ao mês

    public ContaPoupanca(String numero, Cliente cliente, double rendimento) {
        super(numero, cliente, "ContaPoupanca");
        this.rendimento = rendimento;
    }

    @Override
    protected boolean podeSacar(double valor) {
        return saldo >= valor;
    }

    public void aplicarRendimentoMensal() {
        double ganho = saldo * rendimento;
        if (ganho > 0) {
            saldo += ganho;
            registrarTransacao("RENDIMENTO", ganho, "Rendimento mensal poup.");
        }
    }
}


**Depois:**
Mantive a mesma ideia, mas deixei mais clara a função de aplicar juros mensais.

public class ContaPoupanca extends Conta {
    private final double rendimentoMensal;

    public ContaPoupanca(String numero, Cliente cliente, double rendimentoMensal) {
        super(numero, cliente);
        this.rendimentoMensal = rendimentoMensal;
    }

    @Override
    protected boolean podeSacar(double valor) { return saldo >= valor; }

    public void aplicarRendimentoMensal() {
        double ganho = saldo * rendimentoMensal;
        if (ganho > 0) {
            saldo += ganho;
            registrarTransacao("RENDIMENTO", ganho, "Rendimento mensal poup.");
        }
    }
}

**Conceito:**
LSP + SRP. Ela continua respeitando o contrato da conta e cuida só das suas próprias regras.