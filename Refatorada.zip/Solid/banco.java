import java.util.ArrayList;
import java.util.List;

public class Banco {
    private final String nome;
    private final List<Conta> contas = new ArrayList<>();

    public Banco(String nome) { this.nome = nome; }

    public void adicionarConta(Conta conta) { contas.add(conta); }

    public boolean removerConta(String numero) {
        return contas.removeIf(c -> c.getNumero().equals(numero));
    }

    public List<Conta> getContas() { return Collections.unmodifiableList(contas); }

    public Optional<Conta> encontrarContaPorNumero(String numero) {
        return contas.stream().filter(c -> c.getNumero().equals(numero)).findFirst();
    }

    public Set<String> infosClientes() {
        Set<String> infos = new LinkedHashSet<>();
        for (Conta c : contas) infos.add(c.getCliente().getInfo());
        return infos;
    }
}

