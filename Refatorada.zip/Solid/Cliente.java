public class Cliente {
    public final String nome;
    public final String cpf;
    public final String endereco;
    public final String telefone;

    public Cliente(String nome, String cpf, String endereco, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public String getInfo() {
        return String.format("Cliente: %s | CPF: %s | Endereço: %s | Telefone: %s",
                nome, cpf, endereco, telefone);
    }

    public String getNome() { return nome; }
}
